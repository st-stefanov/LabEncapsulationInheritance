using System.Data.SqlClient;

namespace WinFormsApp1
{
    public partial class MainForm1 : Form
    {

        private SqlConnection _db;
        public MainForm1(SqlConnection db)
        {
            _db = db;
            InitializeComponent();
        }
    }
}